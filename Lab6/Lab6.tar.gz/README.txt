Melissa Castillo
SID: 861157259
May 17, 2015

Yes, my function is a stable sort. It only swaps when it finds a value that
is strictly smaller than it. Using specific test inputs, where the inputs 
are already in order, selectionsort does not do any swaps or copies, which
means that the sort if stable since it does not move the order of the
already sorted elements. 